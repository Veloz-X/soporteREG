<div class="search">
    <input type="text" class="form-control search-input" placeholder="{{ __('translation::translation.search') }}" name="{{ $name }}" value="{{ $value }}">
</div>