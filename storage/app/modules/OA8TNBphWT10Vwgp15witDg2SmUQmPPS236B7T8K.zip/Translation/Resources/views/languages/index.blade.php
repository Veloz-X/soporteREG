@extends('translation::layout')

@section('body')
<appm-translation-route />
@endsection