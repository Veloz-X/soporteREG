<template>
  <div>
    <s-frontend></s-frontend>
  </div>
</template>

<script>
import frontend from './Frontend'
export default {
    data(){
      return {

      }
    },
    components: {
      's-frontend': frontend
    }
}
</script>