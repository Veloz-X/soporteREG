<?php

return [
    'name' => 'Customizer'
];
