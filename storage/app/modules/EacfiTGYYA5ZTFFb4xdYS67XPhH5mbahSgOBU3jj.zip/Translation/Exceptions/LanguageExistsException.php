<?php

namespace Modules\Translation\Exceptions;

class LanguageExistsException extends \Exception
{
}
