<?php

namespace Modules\Translation\Exceptions;

class LanguageKeyExistsException extends \Exception
{
}
