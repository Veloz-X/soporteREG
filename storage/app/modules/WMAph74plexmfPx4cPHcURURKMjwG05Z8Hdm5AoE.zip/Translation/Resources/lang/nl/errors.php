<?php

return [
    'language_exists' => 'De taal { :language } bestaat al',
    'key_exists' => 'De vertaalsleutel { :key } bestaat al',
];
